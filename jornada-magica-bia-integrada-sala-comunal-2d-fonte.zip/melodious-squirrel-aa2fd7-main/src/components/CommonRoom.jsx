import { useState } from "react";
import { ArrowLeft, Sparkles, ScrollText, Heart, Cake, RotateCcw } from "lucide-react";
import { magicAudio } from "../lib/audio";

const RIDDLES = [
  {
    chapter: "Pergaminho I · O valor da casa",
    title: "O que cresce quando é dividido?",
    verse: "Não sou ouro, embora brilhe;\nnão sou chama, mas aqueço.\nQuando me ofereces a alguém,\nem vez de diminuir, eu cresço.\nO que sou?",
    options: ["Orgulho", "Amizade", "Silêncio", "Riqueza"], answer: 1,
    hint: "Pense no que se fortalece quando é compartilhado com alguém.",
    success: "Muito bem! Na Lufa-Lufa, a generosidade nunca deixa ninguém mais pobre."
  },
  {
    chapter: "Pergaminho II · A pista escondida",
    title: "A palavra que abre caminhos",
    verse: "Tenho quatro letras e começo com L.\nNão sou lugar, mas faço alguém pertencer.\nSou provada nas pequenas atitudes,\ne quebrada quando escolhemos esconder.\nQue valor sou eu?",
    options: ["Lealdade", "Lembrança", "Liberdade", "Luz"], answer: 0,
    hint: "É permanecer ao lado de alguém e ser digno de confiança.",
    success: "Acertou! A confiança é uma magia que se constrói escolha após escolha."
  },
  {
    chapter: "Pergaminho III · O enigma da balança",
    title: "A escolha invisível",
    verse: "Duas pessoas precisam de ajuda.\nUma pode retribuir; a outra, talvez nunca.\nSe escolhes ajudar mesmo assim,\nqual qualidade estás a demonstrar?",
    options: ["Esperteza", "Vaidade", "Bondade", "Pressa"], answer: 2,
    hint: "Não depende de receber algo em troca: é fazer o bem porque é o certo.",
    success: "Perfeito! Fazer o bem sem esperar recompensa é uma das maiores forças desta casa."
  },
  {
    chapter: "Pergaminho IV · O segredo dourado",
    title: "A última chave",
    verse: "Não posso ser guardado numa caixa,\nnem comprado com moedas de ouro.\nNasço quando escolhes cuidar,\nmesmo sem aplausos ou tesouro.\nJunta amizade, lealdade e bondade:\nqual é a magia que as mantém unidas?",
    options: ["Ser melhor que todos", "Ter sempre razão", "Coração generoso", "Nunca cometer erros"], answer: 2,
    hint: "Não é perfeição nem competição: é a maneira como tratas os outros.",
    success: "O último selo foi quebrado. A magia da Lufa-Lufa estava no teu coração desde o início!"
  }
];

export default function CommonRoom({ onBack, onEnterMemories, onSolved }) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState("");
  const [hint, setHint] = useState(false);
  const [complete, setComplete] = useState(false);
  const current = RIDDLES[index];

  const choose = (optionIndex) => {
    if (selected !== null || complete) return;
    setSelected(optionIndex);
    if (optionIndex === current.answer) {
      setFeedback(current.success);
      magicAudio.chime?.();
    } else {
      setFeedback("O pergaminho ainda não brilhou… respira, relê as pistas e tenta outra vez.");
    }
  };

  const continueRiddle = () => {
    if (selected !== current.answer) {
      setSelected(null);
      setFeedback("");
      return;
    }
    if (index === RIDDLES.length - 1) {
      setComplete(true);
      onSolved?.();
      magicAudio.chime?.(783.99);
      return;
    }
    setIndex((value) => value + 1);
    setSelected(null);
    setFeedback("");
    setHint(false);
  };

  const restart = () => {
    setIndex(0); setSelected(null); setFeedback(""); setHint(false); setComplete(false);
  };

  return (
    <section className="huffle-room" aria-label="Sala Comunal da Lufa-Lufa">
      <div className="huffle-room__shade" />
      <header className="huffle-room__topbar">
        <button className="huffle-back" onClick={onBack} type="button"><ArrowLeft size={18}/> Voltar</button>
        <div className="huffle-title"><span className="huffle-crest">♟</span><div><strong>Sala Comunal da Lufa-Lufa</strong><small>Aqui, a amizade é uma força.</small></div></div>
        <div className="huffle-progress">{complete ? "4 / 4" : `${index + 1} / ${RIDDLES.length}`} <span>pergaminhos</span></div>
      </header>

      <main className={`huffle-parchment ${complete ? "is-complete" : ""}`} key={complete ? "finish" : index}>
        <div className="huffle-parchment__ornament">✦　♟　✦</div>
        {complete ? (
          <div className="huffle-finale">
            <div className="huffle-final-sparkle"><Sparkles size={28}/></div>
            <p className="huffle-kicker">O último selo foi aberto</p>
            <h1>Conseguiste, Bia!</h1>
            <p className="huffle-final-copy">A maior magia da Lufa-Lufa é a bondade que deixamos no mundo. E agora… há uma surpresa à tua espera.</p>
            <div className="huffle-cake" aria-hidden="true">🎂</div>
            <h2>O bolo mágico apareceu!</h2>
            <p className="huffle-final-copy">Que nunca te faltem motivos para sorrir, pessoas para abraçar e sonhos para celebrar.</p>
            <button className="huffle-primary" onClick={onEnterMemories} type="button"><Heart size={18}/> Continuar a jornada <Sparkles size={17}/></button>
            <button className="huffle-restart" onClick={restart} type="button"><RotateCcw size={15}/> Rever os enigmas</button>
          </div>
        ) : (
          <>
            <p className="huffle-kicker"><ScrollText size={15}/> {current.chapter}</p>
            <h1>{current.title}</h1>
            <p className="huffle-verse">{current.verse}</p>
            <div className="huffle-options" role="group" aria-label="Escolha uma resposta">
              {current.options.map((option, i) => {
                const isSelected = selected === i;
                const isCorrect = selected !== null && i === current.answer;
                return <button key={option} className={`huffle-option ${isSelected ? "is-selected" : ""} ${isCorrect ? "is-correct" : ""}`} onClick={() => choose(i)} type="button" disabled={selected !== null}>
                  <span className="huffle-option__letter">{String.fromCharCode(65 + i)}</span><span>{option}</span><span className="huffle-option__mark">{isCorrect ? "✦" : "›"}</span>
                </button>;
              })}
            </div>
            {hint && <p className="huffle-hint"><Sparkles size={15}/> {current.hint}</p>}
            {feedback && <div className={`huffle-feedback ${selected === current.answer ? "is-good" : "is-wrong"}`} role="status">{feedback}</div>}
            <div className="huffle-actions">
              <button className="huffle-hint-button" onClick={() => setHint((value) => !value)} type="button"><Sparkles size={16}/> {hint ? "Esconder pista" : "Pedir uma pista"}</button>
              {selected !== null && <button className="huffle-primary" onClick={continueRiddle} type="button">{selected === current.answer ? (index === RIDDLES.length - 1 ? "Revelar a surpresa" : "Próximo pergaminho") : "Tentar novamente"} <span>→</span></button>}
            </div>
            <div className="huffle-dots" aria-label={`Pergaminho ${index + 1} de ${RIDDLES.length}`}>{RIDDLES.map((_, i) => <span key={i} className={i < index ? "is-past" : i === index ? "is-current" : ""}/>)}</div>
          </>
        )}
      </main>

      <aside className="huffle-side-note"><span>✦</span> Pensa com o coração,<nobr> </nobr>mas não te esqueças da razão.</aside>
      <div className="huffle-room__footer"><span>✦</span> A resposta certa aproxima-te da surpresa final <span>✦</span></div>
    </section>
  );
}
